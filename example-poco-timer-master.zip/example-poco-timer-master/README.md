# example-poco-timer

Example timer with POCO C++ libraries installed with Conan C/C++ package manager